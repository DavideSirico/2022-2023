#include <stdio.h>
#include "calcolatrice.h"
int main(){
	somma(1,4);
	return 0;
}
