int somma(int a,int b){
	return a+b;
}

int sottrazione(int a,int b){
	return a-b;
}
int moltiplicazione(int a,int b){
	return a*b;
}
int quadrato(int a){
	return a*a;
}
int cubo(int a){
	return a*a*a;
}
int incremento(int a){
	return a+1;
}
int decremento(int a){
	return a-1;
}
